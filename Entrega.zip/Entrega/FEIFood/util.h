#ifndef UTIL_H
#define UTIL_H

void lerLinha(char *buffer, int tamanho);
void pausarTela();

#endif
